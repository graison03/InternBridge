D=/home/workspace/my-project/php-ext
cd /home/workspace/my-project
php -d extension=$D/mysqlnd.so -d extension=$D/pdo_mysql.so -d extension=$D/mysqli.so -S 0.0.0.0:8080 -t /home/workspace/my-project/public
