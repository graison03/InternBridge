# InternBridge

A custom PHP + MySQL internship portal for students and companies.

## Stack
HTML, CSS, JavaScript, PHP, MySQL.

## Setup
1. Import `database/internbridge.sql` into MySQL.
2. Open `public/config/database.php`.
3. Replace the five `YOUR_DB_*` values with your database credentials.
4. Point your PHP server document root to `public`.
5. Open `index.php`.
6. Register as a Student or Company.

## Nimbus
If using a hosted Nimbus database, use the exact host, port, database name, username and password shown in your Nimbus database details.

## Important
Do not commit real database passwords to a public repository.
