<?php
require_once "../config/database.php";require_once "../includes/auth.php";require_role("company");
$s=$pdo->prepare("SELECT id FROM companies WHERE user_id=?");$s->execute([$_SESSION['user_id']]);$cid=$s->fetchColumn();$msg="";
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=$pdo->prepare("INSERT INTO internships(company_id,title,description,skills,location,work_mode,duration,deadline) VALUES(?,?,?,?,?,?,?,?)");
 $s->execute([$cid,trim($_POST['title']),trim($_POST['description']),trim($_POST['skills']),trim($_POST['location']),$_POST['work_mode'],trim($_POST['duration']),$_POST['deadline']]);
 header("Location: internships.php");exit;
}
$title="Post Internship";$cssPath="../css/style.css";$jsPath="../js/app.js";$homePath="../index.php";$rootPath="../";require "../includes/header.php";
?>
<div class="narrow"><span class="eyebrow">NEW OPPORTUNITY</span><h1>Post an internship</h1><form class="form-card" method="post">
<label>Role title<input name="title" placeholder="Frontend Development Intern" required></label>
<label>Description<textarea name="description" rows="6" required></textarea></label>
<label>Skills<input name="skills" placeholder="HTML, CSS, JavaScript, PHP" required></label>
<div class="two"><label>Location<input name="location" placeholder="Chennai"></label><label>Work mode<select name="work_mode"><option>Remote</option><option>Hybrid</option><option>On-site</option></select></label></div>
<div class="two"><label>Duration<input name="duration" placeholder="3 months"></label><label>Deadline<input type="date" name="deadline" required></label></div>
<button class="btn primary">Publish internship →</button></form></div>
<?php require "../includes/footer.php"; ?>
