<?php
require_once "../config/database.php";require_once "../includes/auth.php";require_role("company");
$s=$pdo->prepare("SELECT id,company_name FROM companies WHERE user_id=?");$s->execute([$_SESSION['user_id']]);$co=$s->fetch();
$s=$pdo->prepare("SELECT COUNT(*) FROM internships WHERE company_id=?");$s->execute([$co['id']]);$roles=$s->fetchColumn();
$s=$pdo->prepare("SELECT COUNT(*) FROM applications a JOIN internships i ON i.id=a.internship_id WHERE i.company_id=?");$s->execute([$co['id']]);$apps=$s->fetchColumn();
$title="Company Dashboard";$cssPath="../css/style.css";$jsPath="../js/app.js";$homePath="../index.php";$rootPath="../";require "../includes/header.php";
?>
<section class="welcome">
  <div>
    <span class="eyebrow">COMPANY HUB</span>
    <h1><?= htmlspecialchars($co['company_name']) ?></h1>
    <p class="muted">Manage your openings and review incoming talent.</p>
  </div>
  <a class="btn primary" href="add_internship.php">+ Post a role</a>
</section>
<div class="stat-strip">
  <div><span>Roles posted</span><b><?= $roles ?></b></div>
  <div><span>Applicants received</span><b><?= $apps ?></b></div>
  <div><span>Talent access</span><b>24/7</b></div>
</div>
<h2 class="list-title">What would you like to do?</h2>
<div class="action-list">
  <a class="action-row" href="add_internship.php"><i>1</i><div><h3>Post a new role</h3><p>Publish an internship opening.</p></div><em>→</em></a>
  <a class="action-row" href="internships.php"><i>2</i><div><h3>Manage your posts</h3><p>Review the listings you have published.</p></div><em>→</em></a>
  <a class="action-row" href="applicants.php"><i>3</i><div><h3>Review applicants</h3><p>Shortlist and update candidate status.</p></div><em>→</em></a>
</div>
<?php require "../includes/footer.php"; ?>
