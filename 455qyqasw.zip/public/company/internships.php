<?php
require_once "../config/database.php";require_once "../includes/auth.php";require_role("company");
$s=$pdo->prepare("SELECT * FROM companies WHERE user_id=?");$s->execute([$_SESSION['user_id']]);$cid=$s->fetchColumn();$s=$pdo->prepare("SELECT * FROM internships WHERE company_id=? ORDER BY created_at DESC");$s->execute([$cid]);$rows=$s->fetchAll();
$title="My Internships";$cssPath="../css/style.css";$jsPath="../js/app.js";$homePath="../index.php";$rootPath="../";require "../includes/header.php";
?>
<div class="section-head"><div><span class="eyebrow">YOUR LISTINGS</span><h1>My posts</h1></div><a class="btn primary" href="add_internship.php">+ Post a role</a></div>
<div class="card-grid">
  <?php foreach($rows as $r): ?>
    <article class="intern-card">
      <div class="card-top"><span class="pill"><?= htmlspecialchars($r['work_mode']) ?></span><small>Deadline <?= htmlspecialchars($r['deadline']) ?></small></div>
      <h3><?= htmlspecialchars($r['title']) ?></h3>
      <div class="card-bottom"><small>Posted role</small><a href="applicants.php?internship=<?= (int)$r['id'] ?>">Review applicants →</a></div>
    </article>
  <?php endforeach; ?>
</div>
<?php if(!$rows): ?><p class="empty">You have not posted any role yet.</p><?php endif; ?>
<?php require "../includes/footer.php"; ?>
