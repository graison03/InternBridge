function toggleCompany(){
 const picked=document.querySelector('input[name="role"]:checked');
 const sel=document.getElementById("role");
 const val=picked?picked.value:(sel?sel.value:"student");
 const box=document.getElementById("companyField");
 if(box) box.classList.toggle("hidden",val!=="company");
}
document.addEventListener("DOMContentLoaded",()=>{
 document.querySelectorAll('input[name="role"]').forEach(r=>r.addEventListener("change",toggleCompany));
 toggleCompany();
});
document.addEventListener("DOMContentLoaded",()=>{
 document.querySelectorAll("form[data-validate]").forEach(form=>{
   form.addEventListener("submit",e=>{
     const p=form.querySelector('input[name="password"]');
     if(p&&p.value.length<6){e.preventDefault();alert("Password must contain at least 6 characters.");}
   });
 });
});

/* Show / hide password (eye button) - auto-applies to every password field */
document.addEventListener("DOMContentLoaded",()=>{
 const eye='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
 const eyeOff='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20C5 20 1 12 1 12a18.5 18.5 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.1 9.1 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><path d="M14.12 14.12A3 3 0 1 1 9.88 9.88"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
 document.querySelectorAll('input[type="password"]').forEach(input=>{
   if(input.parentElement.classList.contains("pw-wrap")) return;
   const wrap=document.createElement("span");
   wrap.className="pw-wrap";
   input.parentNode.insertBefore(wrap,input);
   wrap.appendChild(input);
   const btn=document.createElement("button");
   btn.type="button";
   btn.className="pw-toggle";
   btn.setAttribute("aria-label","Show password");
   btn.setAttribute("aria-pressed","false");
   btn.innerHTML=eye;
   btn.addEventListener("click",()=>{
     const show=input.type==="password";
     input.type=show?"text":"password";
     btn.innerHTML=show?eyeOff:eye;
     btn.setAttribute("aria-label",show?"Hide password":"Show password");
     btn.setAttribute("aria-pressed",show?"true":"false");
     input.focus();
   });
   wrap.appendChild(btn);
 });
});
