<?php
require_once __DIR__ . "/config/database.php";
$title = "Find your next opportunity";
$cssPath = "css/style.css"; $jsPath = "js/app.js"; $homePath = "index.php"; $rootPath = "";
$stmt = $pdo->query("SELECT i.*, c.company_name FROM internships i JOIN companies c ON c.id=i.company_id WHERE i.deadline >= CURDATE() ORDER BY i.created_at DESC LIMIT 6");
$internships = $stmt->fetchAll();
require "includes/header.php";
?>
<section class="hero">
  <div class="hero-copy">
    <div class="eyebrow">CAREER DISCOVERY PLATFORM</div>
    <h1>Turn your skills into your <em>next opportunity.</em></h1>
    <p>InternBridge connects ambitious students with companies offering meaningful internships.</p>
    <div class="hero-actions">
      <a class="btn primary" href="register.php">Start exploring →</a>
      <a class="btn ghost" href="login.php">I already have an account</a>
    </div>
  </div>
  <div class="hero-panel">
    <div class="panel-label">LIVE OPPORTUNITIES</div>
    <div class="metric"><strong><?= count($internships) ?>+</strong><span>fresh listings</span></div>
    <div class="mini-line"><span>Student-ready</span><b>●</b></div>
    <div class="mini-line"><span>Company verified</span><b>●</b></div>
  </div>
</section>

<section class="section">
  <div class="section-head"><div><span class="eyebrow">HOW IT WORKS</span><h2>Three steps to your first role</h2></div></div>
  <div class="steps">
    <div class="step"><i>1</i><h3>Create your profile</h3><p>Sign up as a student and list your skills.</p></div>
    <div class="step"><i>2</i><h3>Find a match</h3><p>Search roles by skill, company or work mode.</p></div>
    <div class="step"><i>3</i><h3>Apply and track</h3><p>Send applications and follow every status.</p></div>
  </div>
</section>

<section class="section">
  <div class="section-head"><div><span class="eyebrow">LATEST ROLES</span><h2>Recently added internships</h2></div><a href="login.php" class="text-link">View all →</a></div>
  <div class="job-list">
    <?php foreach ($internships as $i): ?>
      <article class="job-row">
        <span class="company-dot"><?= strtoupper(substr($i['company_name'],0,1)) ?></span>
        <div class="job-main"><h3><?= htmlspecialchars($i['title']) ?></h3><p class="muted"><?= htmlspecialchars($i['company_name']) ?> · <?= htmlspecialchars($i['location']) ?> · <?= htmlspecialchars($i['duration']) ?></p></div>
        <div class="job-side"><span class="pill"><?= htmlspecialchars($i['work_mode']) ?></span><small>Deadline <?= htmlspecialchars($i['deadline']) ?></small><a class="btn ghost" href="login.php">Explore</a></div>
      </article>
    <?php endforeach; ?>
    <?php if (!$internships): ?><p class="empty">No open roles right now. Check back soon.</p><?php endif; ?>
  </div>
</section>
<?php require "includes/footer.php"; ?>
