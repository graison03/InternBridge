<?php
require_once "../config/database.php"; require_once "../includes/auth.php"; require_role("student");
$q=trim($_GET['q']??''); $mode=trim($_GET['mode']??'');
$sql="SELECT i.*,c.company_name FROM internships i JOIN companies c ON c.id=i.company_id WHERE i.deadline>=CURDATE()";
$params=[];
if($q){$sql.=" AND (i.title LIKE ? OR i.skills LIKE ? OR c.company_name LIKE ?)"; $like="%$q%"; $params=[$like,$like,$like];}
if($mode){$sql.=" AND i.work_mode=?"; $params[]=$mode;}
$sql.=" ORDER BY i.created_at DESC";
$s=$pdo->prepare($sql); $s->execute($params); $rows=$s->fetchAll();
$title="Internships"; $cssPath="../css/style.css"; $jsPath="../js/app.js"; $homePath="../index.php"; $rootPath="../";
require "../includes/header.php";
?>
<div class="section-head"><div><span class="eyebrow">BROWSE ROLES</span><h1>Open internships</h1><p class="muted"><?= count($rows) ?> role(s) found</p></div></div>
<form class="searchbar" method="get">
  <input name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Search role, company or skill...">
  <?php if($mode): ?><input type="hidden" name="mode" value="<?= htmlspecialchars($mode) ?>"><?php endif; ?>
  <button class="btn primary">Search</button>
</form>
<div class="chips">
  <?php foreach(['' => 'All', 'Remote' => 'Remote', 'Hybrid' => 'Hybrid', 'On-site' => 'On-site'] as $v => $l): $qs = http_build_query(array_filter(['q' => $q, 'mode' => $v])); ?>
    <a class="chip <?= $mode === (string)$v ? 'on' : '' ?>" href="internships.php<?= $qs ? '?'.$qs : '' ?>"><?= $l ?></a>
  <?php endforeach; ?>
</div>
<div class="job-list">
  <?php foreach($rows as $i): ?>
    <article class="job-row">
      <span class="company-dot"><?= strtoupper(substr($i['company_name'],0,1)) ?></span>
      <div class="job-main">
        <h3><?= htmlspecialchars($i['title']) ?></h3>
        <p class="muted"><?= htmlspecialchars($i['company_name']) ?> · <?= htmlspecialchars($i['location']) ?> · <?= htmlspecialchars($i['duration']) ?></p>
        <p class="job-desc"><?= htmlspecialchars($i['description']) ?></p>
      </div>
      <div class="job-side"><span class="pill"><?= htmlspecialchars($i['work_mode']) ?></span><small>Until <?= htmlspecialchars($i['deadline']) ?></small><a class="btn ghost" href="details.php?id=<?= (int)$i['id'] ?>">View role →</a></div>
    </article>
  <?php endforeach; ?>
  <?php if(!$rows): ?><p class="empty">No roles match your search.</p><?php endif; ?>
</div>
<?php require "../includes/footer.php"; ?>
