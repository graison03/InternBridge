<?php
require_once "../config/database.php"; require_once "../includes/auth.php"; require_role("student");
$id=(int)($_GET['id']??0);
$s=$pdo->prepare("SELECT i.*,c.company_name FROM internships i JOIN companies c ON c.id=i.company_id WHERE i.id=?"); $s->execute([$id]); $i=$s->fetch();
if(!$i){header("Location: internships.php");exit;}
$title=$i['title']; $cssPath="../css/style.css"; $jsPath="../js/app.js"; $homePath="../index.php"; $rootPath="../";
require "../includes/header.php";
?>
<div class="detail"><div><span class="eyebrow"><?= htmlspecialchars($i['company_name']) ?></span><h1><?= htmlspecialchars($i['title']) ?></h1><div class="tags"><span><?= htmlspecialchars($i['work_mode']) ?></span><span><?= htmlspecialchars($i['location']) ?></span><span><?= htmlspecialchars($i['duration']) ?></span></div><h2>About this role</h2><p><?= nl2br(htmlspecialchars($i['description'])) ?></p><h2>Skills</h2><p><?= htmlspecialchars($i['skills']) ?></p></div><aside class="apply-box"><strong>Application deadline</strong><div class="big-date"><?= htmlspecialchars($i['deadline']) ?></div><form method="post" action="apply.php"><input type="hidden" name="internship_id" value="<?= $id ?>"><button class="btn primary full">Apply now →</button></form></aside></div>
<?php require "../includes/footer.php"; ?>
