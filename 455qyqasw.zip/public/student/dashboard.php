<?php

require_once "../config/database.php";
require_once "../includes/auth.php";

require_role("student");

$uid = $_SESSION['user_id'];

$s = $pdo->prepare("SELECT * FROM students WHERE user_id = ?");
$s->execute([$uid]);
$student = $s->fetch();

$s = $pdo->prepare("SELECT COUNT(*) FROM applications WHERE student_id = ?");
$s->execute([$student['id']]);
$applications = $s->fetchColumn();

$s = $pdo->query("SELECT COUNT(*) FROM internships WHERE deadline >= CURDATE()");
$open = $s->fetchColumn();

/* Count skills */
$skillsCount = 0;

if (!empty($student['skills'])) {
    $skillsArray = explode(",", $student['skills']);

    foreach ($skillsArray as $skill) {
        if (trim($skill) !== "") {
            $skillsCount++;
        }
    }
}

$title = "Student Dashboard";
$cssPath = "../css/style.css";
$jsPath = "../js/app.js";
$homePath = "../index.php";
$rootPath = "../";

require "../includes/header.php";

?>
<section class="welcome">
  <div>
    <span class="eyebrow">STUDENT HUB</span>
    <h1>Welcome back, <?= htmlspecialchars($_SESSION['name']) ?></h1>
    <p class="muted">Here is a quick look at where you stand today.</p>
  </div>
  <a class="btn primary" href="internships.php">Browse roles →</a>
</section>
<div class="stat-strip">
  <div><span>Applications sent</span><b><?= $applications ?></b></div>
  <div><span>Roles open now</span><b><?= $open ?></b></div>
  <div><span>Skills on profile</span><b><?= $skillsCount ?></b></div>
</div>
<h2 class="list-title">What would you like to do?</h2>
<div class="action-list">
  <a class="action-row" href="profile.php"><i>1</i><div><h3>Build your profile</h3><p>Add your skills and a short bio.</p></div><em>→</em></a>
  <a class="action-row" href="internships.php"><i>2</i><div><h3>Browse roles</h3><p>Search internships that fit you.</p></div><em>→</em></a>
  <a class="action-row" href="applications.php"><i>3</i><div><h3>Check your applications</h3><p>See the status of everything you applied to.</p></div><em>→</em></a>
</div>
<?php require "../includes/footer.php"; ?>