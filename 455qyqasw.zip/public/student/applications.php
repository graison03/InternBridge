<?php
require_once "../config/database.php"; require_once "../includes/auth.php"; require_role("student");
$s=$pdo->prepare("SELECT a.*,i.title,c.company_name FROM applications a JOIN students st ON st.id=a.student_id JOIN internships i ON i.id=a.internship_id JOIN companies c ON c.id=i.company_id WHERE st.user_id=? ORDER BY a.applied_at DESC");$s->execute([$_SESSION['user_id']]);$rows=$s->fetchAll();
$title="Applications";$cssPath="../css/style.css";$jsPath="../js/app.js";$homePath="../index.php";$rootPath="../";require "../includes/header.php";
?>
<div class="section-head"><div><span class="eyebrow">TRACKING</span><h1>Application tracker</h1></div></div>
<div class="job-list">
  <?php foreach($rows as $r): ?>
    <article class="job-row">
      <span class="company-dot"><?= strtoupper(substr($r['company_name'],0,1)) ?></span>
      <div class="job-main"><h3><?= htmlspecialchars($r['title']) ?></h3><p class="muted"><?= htmlspecialchars($r['company_name']) ?> · Applied <?= htmlspecialchars(substr($r['applied_at'],0,10)) ?></p></div>
      <div class="job-side"><span class="status"><?= htmlspecialchars($r['status']) ?></span></div>
    </article>
  <?php endforeach; ?>
  <?php if(!$rows): ?><p class="empty">You have not applied to any role yet.</p><?php endif; ?>
</div>
<?php require "../includes/footer.php"; ?>
