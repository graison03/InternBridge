<?php
require_once __DIR__ . "/config/database.php";
if (session_status() === PHP_SESSION_NONE) session_start();
if (!empty($_SESSION['user_id'])) { header("Location: " . ($_SESSION['role']==='student' ? "student/dashboard.php" : "company/dashboard.php")); exit; }
$error="";
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=trim($_POST['email']??''); $password=$_POST['password']??'';
    $s=$pdo->prepare("SELECT * FROM users WHERE email=? LIMIT 1"); $s->execute([$email]); $u=$s->fetch();
    if ($u && password_verify($password,$u['password'])) {
        session_regenerate_id(true); $_SESSION['user_id']=$u['id']; $_SESSION['name']=$u['name']; $_SESSION['role']=$u['role'];
        header("Location: ".($u['role']==='student'?'student/dashboard.php':'company/dashboard.php')); exit;
    }
    $error="Incorrect email or password.";
}
$title="Login"; $cssPath="css/style.css"; $jsPath="js/app.js"; $homePath="index.php"; $rootPath="";
require "includes/header.php";
?>
<div class="auth-split">
  <aside class="auth-aside">
    <span class="eyebrow">INTERNBRIDGE</span>
    <h2>Pick up right where you left off.</h2>
    <ul class="check-list">
      <li>Track every application in one place</li>
      <li>Find roles that fit your skills</li>
      <li>Companies review talent faster</li>
    </ul>
  </aside>
  <div class="auth-card">
    <span class="eyebrow">SIGN IN</span><h1>Welcome back</h1><p class="muted">Enter your details to continue.</p>
    <?php if(isset($_GET['registered'])): ?><div class="success">Account created. You can sign in now.</div><?php endif; ?>
    <?php if($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="post">
      <label>Email address<input type="email" name="email" required></label>
      <label>Password<input type="password" name="password" required></label>
      <button class="btn primary full">Sign in →</button>
    </form>
    <p class="center muted">No account yet? <a href="register.php">Join InternBridge</a></p>
  </div>
</div>
<?php require "includes/footer.php"; ?>
