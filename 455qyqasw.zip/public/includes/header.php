<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$title = $title ?? "InternBridge";
$__name = $_SESSION['name'] ?? '';
$__ini = preg_match('/^./u', $__name, $__m) ? strtoupper($__m[0]) : '?';
$__cur = basename($_SERVER['SCRIPT_NAME']);
$__r = $rootPath ?? '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($title) ?> | InternBridge</title>
<link rel="stylesheet" href="<?= $cssPath ?? 'css/style.css' ?>">
</head>
<body>
<header class="topbar">
  <a class="brand" href="<?= $homePath ?? 'index.php' ?>"><span>IB</span> InternBridge</a>
  <nav>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <?php if ($_SESSION['role'] === 'student'): ?>
        <a class="<?= $__cur==='dashboard.php'?'active':'' ?>" href="<?= $__r ?>student/dashboard.php">Overview</a>
        <a class="<?= in_array($__cur,['internships.php','details.php','apply.php'])?'active':'' ?>" href="<?= $__r ?>student/internships.php">Browse Roles</a>
        <a class="<?= $__cur==='applications.php'?'active':'' ?>" href="<?= $__r ?>student/applications.php">My Applications</a>
        <a class="<?= $__cur==='profile.php'?'active':'' ?>" href="<?= $__r ?>student/profile.php">My Profile</a>
      <?php else: ?>
        <a class="<?= $__cur==='dashboard.php'?'active':'' ?>" href="<?= $__r ?>company/dashboard.php">Overview</a>
        <a class="<?= $__cur==='internships.php'?'active':'' ?>" href="<?= $__r ?>company/internships.php">My Posts</a>
        <a class="<?= $__cur==='applicants.php'?'active':'' ?>" href="<?= $__r ?>company/applicants.php">Applicants</a>
        <a class="<?= $__cur==='add_internship.php'?'active':'' ?>" href="<?= $__r ?>company/add_internship.php">Post a Role</a>
      <?php endif; ?>
      <span class="user-chip"><i><?= htmlspecialchars($__ini) ?></i><?= htmlspecialchars($__name) ?></span>
      <a class="nav-cta" href="<?= $__r ?>logout.php">Sign out</a>
    <?php else: ?>
      <a class="<?= $__cur==='index.php'?'active':'' ?>" href="<?= $homePath ?? 'index.php' ?>">Home</a>
      <a class="<?= $__cur==='login.php'?'active':'' ?>" href="<?= $__r ?>login.php">Sign in</a>
      <a class="nav-cta" href="<?= $__r ?>register.php">Join now</a>
    <?php endif; ?>
  </nav>
</header>
<main class="page">
