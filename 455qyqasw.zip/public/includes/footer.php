</main>
<footer class="footer">© <?= date('Y') ?> InternBridge · Where students meet opportunity</footer>
<script src="<?= $jsPath ?? 'js/app.js' ?>"></script>
</body>
</html>
